<h1>Lista de mensagens</h1>
<hr>
<br>
<br>
<?php $__currentLoopData = $lmsg; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $umaMsg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <p><b><?php echo e($umaMsg->titulo); ?></b></p>
    <p><?php echo e($umaMsg->texto); ?></p>
    <p><?php echo e($umaMsg->autor); ?></p>
    <p><?php echo e($umaMsg->created_at); ?></p>
    <br>
    <br>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>