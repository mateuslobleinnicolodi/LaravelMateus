<h1>Formulario de Cadastro de Atividade</h1>
<hr>

<?php if($errors->any()): ?>
<div class="container">
    <div class="alert alert-adnger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
</div>
<?php endif; ?>

<form action="/atividades" method="post">
    <?php echo e(csrf_field()); ?>

    Título:         <input type="text" name="title">                    <br>
    Descrição:      <input type="text" name="description">              <br>
    Agendado para:  <input type="datetime-local" name="scheduledto">    <br>
    <input type="submit" value="Salvar">
</form>