<?php

use App\Mensagem;
use Illuminate\Database\Seeder;

class mensagensTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Mensagem::create([
            'titulo' => 'Olá inicial',
            'texto' => 'Olá mundo...',
            'autor' => 'Tiago',
        ]);
    }
}
